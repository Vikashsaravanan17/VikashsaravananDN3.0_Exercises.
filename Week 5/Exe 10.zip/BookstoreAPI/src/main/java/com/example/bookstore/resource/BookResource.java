package com.example.bookstore.resource;

import com.example.bookstore.model.Book;
import org.springframework.hateoas.RepresentationModel;

public class BookResource extends RepresentationModel<BookResource> {

    private final Book book;

    public BookResource(Book book) {
        this.book = book;
    }

    public Book getBook() {
        return book;
    }
}

