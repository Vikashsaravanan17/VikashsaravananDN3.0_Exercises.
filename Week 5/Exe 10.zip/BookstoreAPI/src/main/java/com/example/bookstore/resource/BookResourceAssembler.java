package com.example.bookstore.resource;

import com.example.bookstore.controller.BookController;
import com.example.bookstore.model.Book;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.server.mvc.RepresentationModelAssemblerSupport;
import org.springframework.stereotype.Component;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;

@Component
public class BookResourceAssembler extends RepresentationModelAssemblerSupport<Book, BookResource> {

    public BookResourceAssembler() {
        super(BookController.class, BookResource.class);
    }

    @Override
    public BookResource toModel(Book book) {
        BookResource resource = new BookResource(book);
        Link selfLink = linkTo(methodOn(BookController.class).getBookById(book.getId())).withSelfRel();
        resource.add(selfLink);
        return resource;
    }
}
