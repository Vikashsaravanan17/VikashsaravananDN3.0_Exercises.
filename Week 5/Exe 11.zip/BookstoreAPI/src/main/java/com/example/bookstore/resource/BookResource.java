package com.example.bookstore.resource;

import com.example.bookstore.model.Book;
import org.springframework.hateoas.Link;
import org.springframework.hateoas.RepresentationModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;

public class BookResource extends RepresentationModel<BookResource> {
    private Book book;

    public BookResource(Book book) {
        this.book = book;
        addLinks();
    }

    public Book getBook() {
        return book;
    }

    private void addLinks() {
        Link selfLink = WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(book.getId())).withSelfRel();
        this.add(selfLink); // Correctly add the link to the RepresentationModel
        // You can add more links if necessary
    }
}

