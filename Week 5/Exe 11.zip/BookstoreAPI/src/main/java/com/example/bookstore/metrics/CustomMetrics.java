package com.example.bookstore.metrics;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.MeterRegistry;

@Configuration
public class CustomMetrics {

    @Bean
    public Counter bookCounter(MeterRegistry meterRegistry) {
        return Counter.builder("books.count")
                .description("Total number of books")
                .register(meterRegistry);
    }
}

