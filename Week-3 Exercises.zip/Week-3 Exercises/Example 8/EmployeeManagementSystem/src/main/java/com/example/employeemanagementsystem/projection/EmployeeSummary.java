package com.example.employeemanagementsystem.projection;

public interface EmployeeSummary {
	Long getId();
    String getName();
    String getEmail();
}
