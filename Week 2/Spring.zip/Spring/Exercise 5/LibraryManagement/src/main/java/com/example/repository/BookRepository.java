package com.example.repository;

public class BookRepository {
    public void getBook() {
        System.out.println("Fetching book from the repository.");
    }
}
