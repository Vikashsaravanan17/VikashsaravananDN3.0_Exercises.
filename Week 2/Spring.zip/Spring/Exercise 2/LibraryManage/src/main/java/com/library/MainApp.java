package com.library;


	import org.springframework.context.ApplicationContext;
	import org.springframework.context.support.ClassPathXmlApplicationContext;
	import com.library.service.BookService;

	public class MainApp {

	    public static void main(String[] args) {
	        // Load the Spring context
	        ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");

	        // Retrieve the BookService bean
	        BookService bookService = (BookService) context.getBean("bookService");

	        // Use the bookService instance to print the repository status
	        bookService.printRepositoryStatus();
	    }
	}


