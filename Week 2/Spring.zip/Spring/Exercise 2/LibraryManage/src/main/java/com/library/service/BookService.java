

package com.library.service;

import com.library.repository.BookRepository;

public class BookService {

    private BookRepository bookRepository;

    // Setter method for dependency injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // A sample method to demonstrate the usage of BookRepository
    public void printRepositoryStatus() {
        if (bookRepository != null) {
            System.out.println("BookRepository has been injected successfully.");
        } else {
            System.out.println("BookRepository injection failed.");
        }
    }
}
