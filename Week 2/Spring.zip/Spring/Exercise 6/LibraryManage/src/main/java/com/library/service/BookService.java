package com.library.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import com.library.repository.BookRepository;

@Service
public class BookService {

    private BookRepository bookRepository;

    // Constructor for dependency injection
    @Autowired
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Setter method for dependency injection
    @Autowired
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // A sample method to demonstrate the usage of BookRepository
    public void printRepositoryStatus() {
        if (bookRepository != null) {
            System.out.println("BookRepository has been injected successfully.");
        } else {
            System.out.println("BookRepository injection failed.");
        }
    }
}
